************************************************************************************************************************
Welcome to ruby_assessment
************************************************************************************************************************

This file guides you through steps to install ruby_assessment on Windows
This version has been tested on Ubuntu 12.5 LTS

****************************************************************************************************************************
Installating ruby_assessment in Ubuntu
****************************************************************************************************************************
1] Extract the "Atul_Shimpi-Software Engineer-Ruby.zip" folder on your home directory
Go to source directory in the extracted folder
This directory has source code for 2 applications - "agent" and the "app"

Installing Agent (Remote machine)
------------------------
1] Copy the "agent" directory on remote Linux or Unix machine.
The agent should be installed on remote machine which is accessible from the machine where Web Application is installted
1] Install Ruby 2.1.6  
2] Install Rail 4.2.3
3] Install MySql server
3] Open shell and go inside the "agent" directory
4] Run command - bundle install
5] Run command - rake db:setup
6] Now start the agent using command rails s -b 0.0.0.0 -d
Give http://0.0.0.0:3000/ in the browser. If u welcome page then agent has started.
Thats all. The agent will now start getting cpu and disk usage metrics and save it in its database.
Our web application, will periodically fetch this data from the data. Now lets install the application

To stop the agent do this
1] From inside the "agent" directory give below command
open the file ./tmp/pids/server.pid
This file contains process id of the agent process we started.
To stop it use this command kill -9 <process_id_in_the_file> 

Installing Application (local machine)
--------------------------------------------------
1] Come back to your local machine where you have extracted the assassment zip.
2] Install Ruby 2.1.6  
3] Install Rail 4.2.3
4] Install MySql server
5] Open shell and go inside the "app" directory
6] Run command - bundle install
7] Run command - rake db:setup
8] Now start the agent using command rails s -b 0.0.0.0 -d
Give http://0.0.0.0:3000/ in the browser. You should see application window having some fancy UI.

To stop the application do the same steps are for agent.

User Guide
-----------------------------------------------
How to monitor a remote host
1] Make sure the "agent" and "app" are running on respective hosts
2] On the host where "app" is running, go to browser and navigte to http://0.0.0.0:3000/
This will show the app window.
Click the "Hosts" menu.
Click on "New" menu
Enter the host details on which you have installed the agent.
Enter all the details. Keep the port to 3000.
Click on save button.
3] Click on "Dasbhord" menu.
Wait for 10-15 and refresh the browser ui.
The application collects data from the agent after every 10 min.
If you dont want to wait, then click the "Collect data" button to collect the data manually.
Observe the table on dashboard. It should be showing the Connection, Platform and other details it got from the agent.
If connection is not OK, then
1] Make sure agent is running
2] Refresh the browser window
Dashbord will show how long host is monitored and other details like avg cpu usage and disk usage
4] Click on "Export to PDF" button to export data to pdf
5] Click the details link for each host to see all the montored data

Thats all


     
   
