class HostAndMatricesRecordId < ActiveRecord::Base

end
