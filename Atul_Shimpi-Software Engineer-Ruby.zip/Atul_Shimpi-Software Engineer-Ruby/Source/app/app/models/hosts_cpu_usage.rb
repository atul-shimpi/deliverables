class HostsCPUUsage < HostsAndMatrix
  belongs_to :host
end