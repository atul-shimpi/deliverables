class HostsDiskUsage < HostsAndMatrix
  belongs_to :host
end