class HostConfiguration < ActiveRecord::Base
  belongs_to :host

end
