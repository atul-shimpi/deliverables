require 'test_helper'

class HostConfigurationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
