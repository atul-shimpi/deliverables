require 'test_helper'

class HostAndMatricesRecordIdTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
