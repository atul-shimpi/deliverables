class DiskUsage < MetricUsage
end