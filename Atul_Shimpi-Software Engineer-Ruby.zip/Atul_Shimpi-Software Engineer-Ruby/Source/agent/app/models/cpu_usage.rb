class CpuUsage < MetricUsage

end
