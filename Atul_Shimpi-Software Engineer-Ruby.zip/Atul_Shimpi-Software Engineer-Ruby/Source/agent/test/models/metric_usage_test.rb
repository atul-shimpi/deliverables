require 'test_helper'

class MetricUsageTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
