class RESTApiController < ApplicationController
end
