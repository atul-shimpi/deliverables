class PurchaseType < ActiveRecord::Base
end
