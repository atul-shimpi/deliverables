class ApplicationMailer < ActionMailer::Base


end
