module PropertiesHelper
end
